# 在 GitHub 编译“好啊有”APK

1. 在 GitHub 新建一个仓库。
2. 把本源码包解压后的所有文件上传到仓库根目录，或用 Git push 到仓库。
3. 打开仓库页面的 **Actions**。
4. 选择左侧 **Build 好啊有 APK**。
5. 点击 **Run workflow**。
6. 等编译完成后，在本次 workflow 页面底部的 **Artifacts** 下载 **好啊有-APK**。

说明：
- 这个 workflow 会自动拉取 `mihomo` 核心源码，所以即使你是直接上传 ZIP 源码，也可以在 GitHub 上编译。
- 产物是 Debug APK，适合直接安装测试；不需要配置签名密钥。
- 如果要发布正式版，再配置 release 签名密钥并使用项目原有 release workflow。
