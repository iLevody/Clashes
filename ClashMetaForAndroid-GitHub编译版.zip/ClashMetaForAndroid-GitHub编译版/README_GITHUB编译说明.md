# GitHub Actions 编译说明

这个包已经整理成“上传到 GitHub 后可一键编译 APK”的版本。

## 使用方法

1. 在 GitHub 新建一个仓库。
2. 把本目录里的所有文件上传到仓库根目录，或用 Git 提交推送到 `main` / `master`。
3. 打开仓库的 **Actions** 页面。
4. 选择 **Build Android APK**。
5. 点击 **Run workflow**，默认选择：
   - `flavor`: `alpha`
   - `build_type`: `release`
6. 编译成功后，在本次 workflow 页面底部下载 artifact：`cmfa-alpha-release-apk`。

## 我改了什么

- 新增 `.github/workflows/build-apk.yml`。
- 原 ZIP 中的旧 workflow 已移动到 `.github/workflows-disabled-original/`，避免旧流程在 push 时自动触发并因为缺少 secrets 或 action 版本不匹配而失败。
- 工作流会自动 clone `MetaCubeX/mihomo` 的 `Alpha` 分支到 `core/src/foss/golang/clash`，解决 ZIP 上传后 submodule 目录为空的问题。
- 工作流会安装 JDK 21、Android SDK 35、NDK `29.0.14206865`、Gradle 和 Go。

## 签名说明

不设置签名 secrets 也能编译，release APK 会回退到 debug 签名，适合自用测试。

如果要用仓库里的 `release.keystore` 做正式签名，请在 GitHub 仓库：

`Settings` → `Secrets and variables` → `Actions` → `New repository secret`

添加三个 secret：

- `SIGNING_STORE_PASSWORD`
- `SIGNING_KEY_ALIAS`
- `SIGNING_KEY_PASSWORD`

然后重新运行 **Build Android APK**。
